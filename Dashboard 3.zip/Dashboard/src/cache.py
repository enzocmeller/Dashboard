"""A tiny SQLite key/value cache (standard library ``sqlite3``).

Used to make re-runs fast and polite:
- *Immutable* data (ERA5 climate normals, past GLAM composites, GLAM id maps)
  is fetched once and kept forever.
- *Volatile* data (current crop progress/condition, the latest forecast) is not
  cached and is re-fetched on every run, which is what makes the dashboard
  "auto-update every time you run it".
"""
import json
import os
import sqlite3
import time

_conn = None


def init(data_dir):
    global _conn
    os.makedirs(data_dir, exist_ok=True)
    path = os.path.join(data_dir, "cache.sqlite")
    try:
        # timeout: tolerate brief locks (e.g. a OneDrive-synced cache file)
        _conn = sqlite3.connect(path, timeout=5)
        _conn.execute(
            "CREATE TABLE IF NOT EXISTS kv ("
            "  k TEXT PRIMARY KEY,"
            "  v TEXT NOT NULL,"
            "  created REAL NOT NULL"
            ")"
        )
        _conn.commit()
    except sqlite3.Error:
        _conn = None  # run without a cache rather than crash
    return _conn


def get(key):
    if _conn is None:
        return None
    try:
        row = _conn.execute("SELECT v FROM kv WHERE k = ?", (key,)).fetchone()
    except sqlite3.Error:
        return None
    return row[0] if row else None


def set(key, value):
    if _conn is None:
        return
    try:
        _conn.execute(
            "INSERT OR REPLACE INTO kv (k, v, created) VALUES (?, ?, ?)",
            (key, value, time.time()),
        )
        _conn.commit()
    except sqlite3.Error:
        pass  # a locked/corrupt cache must never break the run


def get_json(key):
    raw = get(key)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


def set_json(key, obj):
    set(key, json.dumps(obj))


def cached_json(key, producer):
    """Return cached JSON for ``key`` or call ``producer()``, cache, and return it."""
    hit = get_json(key)
    if hit is not None:
        return hit
    value = producer()
    if value is not None:
        set_json(key, value)
    return value
